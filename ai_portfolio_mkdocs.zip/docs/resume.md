# 📝 Resume

Download [My Resume (PDF)](resume.pdf)

---

## 👨‍🎓 Education
- BS Data Science – University of XYZ (2021–2025)

## 🛠️ Skills
Python, Pandas, Scikit-learn, LangChain, HuggingFace, Streamlit