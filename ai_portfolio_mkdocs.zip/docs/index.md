# 👋 Welcome to My AI Portfolio

I’m an AI and Data Science student passionate about building intelligent systems and solving real-world problems using data.

---

## 🔍 What You'll Find Here:
- My projects in data science, AI, and ML
- Tools and skills I’ve learned
- Resume and contact information