# 🤖 AI & Machine Learning Projects

## 🗣️ Chat with PDFs (RAG)
Built a Retrieval-Augmented Generation chatbot using LangChain & Streamlit.

## 🧠 Sentiment Analysis Bot
Trained BERT model to classify Urdu tweets with 90% accuracy.