# 📊 Data Science Projects

## 🧹 Data Cleaning Dashboard
Cleaned 100k+ rows of agricultural data using Pandas and Streamlit.

## 📈 Price Prediction
Used Linear Regression and Random Forest to predict crop prices with 85% accuracy.